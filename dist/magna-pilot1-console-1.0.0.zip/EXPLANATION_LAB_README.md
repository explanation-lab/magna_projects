# Explanation Lab conversion report

Converted: 2026-11-11T22:08:43.948Z
Source ZIP: magna-pilot1-source-1.0.0.zip
jsPsych: 7.3.4
Experiment version: magna-pilot1-1.0.0
Client version: 1.5.1
Assignment: between_participant
Launch assignment parameter: condition
Launch conditions: p01, p02, p03, p04, p05, p06, p07, p08, p09, p10, p11, p12, p13, p14, p15, p16
Internal condition cells: bicycle_control_o1, bicycle_control_o2, bicycle_control_o3, bicycle_intentional_o1, bicycle_intentional_o2, bicycle_intentional_o3, bicycle_negligence_o1, bicycle_negligence_o2, bicycle_negligence_o3, bicycle_strict_o1, bicycle_strict_o2, bicycle_strict_o3, ladder_control_o1, ladder_control_o2, ladder_control_o3, ladder_intentional_o1, ladder_intentional_o2, ladder_intentional_o3, ladder_negligence_o1, ladder_negligence_o2, ladder_negligence_o3, ladder_strict_o1, ladder_strict_o2, ladder_strict_o3, shelving_control_o1, shelving_control_o2, shelving_control_o3, shelving_intentional_o1, shelving_intentional_o2, shelving_intentional_o3, shelving_negligence_o1, shelving_negligence_o2, shelving_negligence_o3, shelving_strict_o1, shelving_strict_o2, shelving_strict_o3, treadmill_control_o1, treadmill_control_o2, treadmill_control_o3, treadmill_intentional_o1, treadmill_intentional_o2, treadmill_intentional_o3, treadmill_negligence_o1, treadmill_negligence_o2, treadmill_negligence_o3, treadmill_strict_o1, treadmill_strict_o2, treadmill_strict_o3
Demographics: age, sex, ethnicity
Package fingerprint: 9b808989006b230416c097cb4b1d11d76e6055212c92e0cf370b708bdc725e13

## Changes
- Added explanation-lab.config.json with confirmed versions and data mappings.
- Added a frozen local Explanation Lab client at explanation-lab-client.js.
- Preserved the existing Explanation Lab save integration and re-verified its launch assignment wiring.
- Verified that every condition reader in the package uses the Console assignment.

## Warnings from inspection
- None

## Required next steps
1. Open and test the converted study locally.
2. Publish this converted folder through GitHub Pages.
3. Register the public Pages URL in the Explanation Lab Console.
4. Paste the Pages URL into the Console; it will read and verify this manifest automatically.
5. Complete every Sandbox condition and inspect both CSV exports.
6. Do not launch while any readiness item remains incomplete.